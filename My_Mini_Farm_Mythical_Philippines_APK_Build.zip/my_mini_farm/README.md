# My Mini Farm: Mythical Philippines

A mobile-friendly 2D side-scrolling adventure prototype with Filipino folklore-inspired bosses. This is an original small game prototype, not a full Terraria-scale release yet.

## Features in this build
- Touchscreen movement, jump, attack, talk/quest, gathering, mining, crafting, and manual save
- Local progress save/load plus a save attempt when the app is backgrounded or closed
- Wood, stone, coins, a craftable Trailblade, and healing herbs
- Forest, farm hut, Elder NPC, ledges, and pixel-style Canvas characters
- Story boss sequence: Manananggal, Sigbin, then Tikbalang
- Android wrapper configuration via Capacitor and a GitHub Actions debug-APK workflow

## Quick test in a browser
Open `index.html` or `www/index.html` in a modern browser. Some mobile browsers restrict local-file storage; if save/load does not work when opened as a file, test through a local web server or the Android app.

## Build a real Android APK
**This ZIP does not contain a compiled APK.** Use the included workflow to build one in GitHub Actions:

1. Sign in to GitHub and create a new repository.
2. Extract this ZIP on your computer. Upload the contents of the `my_mini_farm` folder (the files inside it, including `.github`) to the repository's `main` branch.
3. In the repository, open **Actions** and enable workflows if prompted.
4. Choose **Build Android APK** in the workflow list, select **Run workflow**, then run it on `main`.
5. Wait for the workflow to finish successfully. Open that run and download the **my-mini-farm-debug-apk** artifact.
6. Extract the downloaded artifact ZIP on your Android phone or computer. It contains `app-debug.apk`. Transfer it to your phone if needed, tap it, and follow Android's prompts to install. Only install APKs you built or trust.

The workflow needs internet access to download Capacitor, Gradle, and Android build tools. Debug APKs are for personal testing, not Play Store release distribution. If GitHub Actions fails, open the failed step's log to identify the build issue.

## Build locally (optional)
Install Node.js 20+, Java 21, and Android Studio with Android SDK Platform 35 and Build Tools 35.0.0, then run in this folder:

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is normally at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Known limitations
This is an early playable prototype with simple Canvas artwork and basic combat. The world is compact; farming plots/crops, complex crafting trees, richer boss attack patterns, persistent mined-node state, and polished character animations are not yet implemented. Save behavior depends on browser/device storage support. The APK workflow builds a test APK but does not sign a Play Store release.
